#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //Начальное состояние
    bookID=0;
    bShelfID=0;
    ShelfID=0;
    ui->groupBox_book->setEnabled(false);
    ui->groupBox_shelf->setEnabled(false);
    ui->pushButton_delbshelf->setEnabled(false);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_addbshelf_clicked()
{
   //Создать шкаф
    Book_shelf bs;
    //Добавить шкаф в список
    bookShelfs.push_back(bs);
    ui->listWidget_bshelf->addItem(QString::number(bookShelfs.size()));

}

void MainWindow::on_listWidget_bshelf_itemClicked(QListWidgetItem *item)
{
    //Получить ID шкафа
    bShelfID = item->text().toInt();
    //активность эл-ты интерфейса
    ui->pushButton_delbshelf->setEnabled(true);
    ui->groupBox_shelf->setEnabled(true);
    ui->pushButton_delshelf->setEnabled(false);
    //получить кол-во полок
    int shelfN = bookShelfs[bShelfID-1].getShelfNumber();
    //Очистить список
    ui->listWidget_shelf->clear();
    ui->listWidget_book->clear();
    //Наполнить список полок
    if(shelfN>0){
        for(int i=1;i<=shelfN;i++){
            ui->listWidget_shelf->addItem(QString::number(i));
        }
    }



}


void MainWindow::on_pushButton_addshelf_clicked()
{
    //Создать полку добавить полку в шкаф
    bookShelfs[bShelfID-1].addshelf();
    //Обновить список
    int ShelfN = bookShelfs[bShelfID-1].getShelfNumber();
    ui->listWidget_shelf->addItem(QString::number(ShelfN));

}

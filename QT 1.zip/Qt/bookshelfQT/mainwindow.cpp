#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFile>
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //Начальное состояние
    bookID=0;
    bShelfID=0;
    ShelfID=0;
    ui->groupBox_book->setEnabled(false);
    ui->groupBox_shelf->setEnabled(false);
    ui->pushButton_delbshelf->setEnabled(false);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_addbshelf_clicked()
{
   //Создать шкаф
    Book_shelf bs;
    //Добавить шкаф в список
    bookShelfs.push_back(bs);
    ui->listWidget_bshelf->addItem(QString::number(bookShelfs.size()));

}

void MainWindow::on_listWidget_bshelf_itemClicked(QListWidgetItem *item)
{
    //Получить ID шкафа
    bShelfID = item->text().toInt();
    //активность эл-ты интерфейса
    ui->pushButton_delbshelf->setEnabled(true);
    ui->groupBox_shelf->setEnabled(true);
    ui->pushButton_delshelf->setEnabled(false);
    //получить кол-во полок
    int shelfN = bookShelfs[bShelfID-1].getShelfNumber();
    //Очистить список
    ui->listWidget_shelf->clear();
    ui->listWidget_book->clear();
    //Наполнить список полок
    if(shelfN>0){
        for(int i=1;i<=shelfN;i++){
            ui->listWidget_shelf->addItem(QString::number(i));
        }
    }



}


void MainWindow::on_pushButton_addshelf_clicked()
{
    //Создать полку добавить полку в шкаф
    bookShelfs[bShelfID-1].addshelf();
    //Обновить список
    int ShelfN = bookShelfs[bShelfID-1].getShelfNumber();
    ui->listWidget_shelf->addItem(QString::number(ShelfN));

}

void MainWindow::on_action_triggered()
{
    //Открываем файл
    QFile file("data.txt");
    if(file.open(QIODevice::WriteOnly)){
        QTextStream out(&file);
        out<<"BOOKSHELF DATA\n";
        //Перебор всех шкафов
        for (int i=0;i<bookShelfs.size();i++){
            //Сохранить шкаф (ID: 1)
            out<<1<<"\n";
            //Получить кол-во полок
            int shelfN = bookShelfs[i].getShelfNumber();
            for (int j=0;j<shelfN;j++) {
                //Сохранить полку (ID: 2)
                 out<<2<<"\n";
                //Получить кол-во книг
                int bookN = bookShelfs[i].getShelf(j).getBookN();
                //Перебор всех книг
                for (int k=0;k<bookN;k++) {
                    //Сохранить книгу (ID: 3)
                    out<<3<<"\n";
                    PrintBook pb = bookShelfs[i].getBook(j,k);
                    out<<"\t"<<QString::fromStdString(pb.GetName())<<"\n";
                    out<<"\t"<<QString::number(pb.GetPages())<<"\n";

                }
            }


        }
    }
}

void MainWindow::on_action_2_triggered()
{
    //Открыть файл
    QFile file("data.txt");
    if(file.open(QIODevice::ReadOnly)) {
        QTextStream in(&file);
        QString line;
        while (in.readLineInto(&line)) {
            int id=line.toInt();
            Book_shelf bs;
            shelf shelf;
            PrintBook pb;
            switch (id) {
            case 1:
                bookShelfs.push_back(bs);
                bShelfID+=1;
                break;
            case 2:
                bookShelfs[bShelfID-1].addshelf();
                ShelfID+=1;
                break;
            case 3:
                pb.setName(in.readLine().toStdString());
                pb.setPages(in.readLine().toInt());
                bookShelfs[bShelfID-1].addBook(pb, ShelfID-1);
                break;

            }

        }
        file.close();
        ui->listWidget_book->clear();
        ui->listWidget_shelf->clear();
        ui->listWidget_bshelf->clear();
        for (int i=1; i<=bookShelfs.size();i++) {
            ui->listWidget_bshelf->addItem(QString::number(i));
            }
        ui->groupBox_book->setEnabled(false);
        ui->groupBox_shelf->setEnabled(false);
        }
    }



